﻿namespace BlazorApp1
{
    internal class ApplicationUser
    {
    }
}